import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(
    private _http: HttpClient
  ) { }

  // method to place order
  public bookWash(order: any) {
    return this._http.post(`http://localhost:9003/order/place-order`, order);
  }

  // get all customers
  public getAllOrders() {
    return this._http.get(`http://localhost:9003/order/get-all-orders`);
  }


  // get all customers
  public getAllOrdersByCustomerName() {
    return this._http.get(`http://localhost:9001/customer/my-orders/`);
  }
}
