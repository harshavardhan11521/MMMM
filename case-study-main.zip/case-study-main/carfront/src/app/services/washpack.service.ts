import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class WashpackService {

  constructor(private _http: HttpClient) { }

  public washpacks() {
    return this._http.get("http://localhost:9005/admin/all-packs");
  }

  // add
  public addWashpacks(washpack: any) {
    return this._http.post("http://localhost:9005/admin/add-pack", washpack);
  }

  // delete
  public deleteWashpacks(packId: any) {
    return this._http.delete(`http://localhost:9005/admin/delete/${packId}`);
  }

  //get a single quiz
  public getWashpack(packId: any) {
    return this._http.get(`http://localhost:9005/admin/${packId}`)
  }

  // Update
  public updateWashpack(washpack: any, packId: any) {
    return this._http.put(`http://localhost:9005/admin/edit-pack/${packId}`, washpack);
  }

}
