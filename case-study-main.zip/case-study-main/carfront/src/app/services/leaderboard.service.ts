import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LeaderboardService {

  constructor(private _http: HttpClient) { }
  public getLeaderboard() {
    return this._http.get("http://localhost:9005/admin/leaderboard");
  }

  // add
  public addToLeaderboard(leader: any) {
    return this._http.post("http://localhost:9005/admin/add-leaderboard", leader);
  }
}
