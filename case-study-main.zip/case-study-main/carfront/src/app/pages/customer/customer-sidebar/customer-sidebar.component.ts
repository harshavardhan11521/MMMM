import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-sidebar',
  templateUrl: './customer-sidebar.component.html',
  styleUrls: ['./customer-sidebar.component.css']
})
export class CustomerSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
