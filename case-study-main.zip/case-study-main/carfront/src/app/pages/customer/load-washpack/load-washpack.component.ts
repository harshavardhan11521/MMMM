import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { WashpackService } from 'src/app/services/washpack.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-load-washpack',
  templateUrl: './load-washpack.component.html',
  styleUrls: ['./load-washpack.component.css']
})
export class LoadWashpackComponent implements OnInit {

  washpacks = [
    {
      packId: '',
      packname: '',
      amount: '',
      description: ''
    }
  ]

  constructor(private _washpack: WashpackService, public dialog: MatDialog, private snack: MatSnackBar) { }

  ngOnInit(): void {
    this._washpack.washpacks().subscribe(
      (data: any) => {
        this.washpacks = data;
        console.log(this.washpacks);

      },
      (error) => {
        console.log("error");
        Swal.fire('Error!', "Error in loading data!", "error");

      }
    )
  }

  matSnack(message: string, action: string) {
    this.snack.open(message, action)
  }

  // // delete Washpacks function
  // deleteQuiz(packId: any) {

  //   Swal.fire({
  //     icon: 'warning',
  //     title: 'Want to delete?',
  //     confirmButtonText: 'Delete',
  //     showCancelButton: true,
  //   }).then((result) => {

  //     if (result.isConfirmed) {

  //       this._washpack.deleteWashpacks(packId).subscribe(
  //         (data) => {
  //           this.washpacks = this.washpacks.filter((_washpack) => _washpack.packId != packId);
  //           Swal.fire("Success", "Washpack Deleted ", 'success');
  //         }, (error) => {
  //           console.log(error);

  //           Swal.fire("Error", "Error in deleting washpack", 'error');

  //         }

  //       );
  //     }

  //   })
  // }

}
