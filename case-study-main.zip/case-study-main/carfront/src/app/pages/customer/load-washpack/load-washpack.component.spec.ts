import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadWashpackComponent } from './load-washpack.component';

describe('LoadWashpackComponent', () => {
  let component: LoadWashpackComponent;
  let fixture: ComponentFixture<LoadWashpackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoadWashpackComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadWashpackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
