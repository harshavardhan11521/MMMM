import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-customer',
  templateUrl: './welcome-customer.component.html',
  styleUrls: ['./welcome-customer.component.css']
})
export class WelcomeCustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
