import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { OrderService } from 'src/app/services/order.service';
import { WashpackService } from 'src/app/services/washpack.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {


  constructor(private _route: ActivatedRoute, private _order: OrderService,
    private _washpack: WashpackService, private login: LoginService, private snack: MatSnackBar) { }
  user: any = null;
  packId = 0;
  washpack: any;


  public order = {
    washName: '',
    carModel: '',
    amount: '',
    customerName: '',
    emailAddress: ''
  }

  ngOnInit(): void {

    this.user = this.login.getUser();
    this.packId = this._route.snapshot.params['packId'];
    // alert(this.packId);
    this._washpack.getWashpack(this.packId).subscribe(
      (data: any) => {
        this.washpack = data;
        console.log(this.washpack);
        this.order.washName = this.washpack.packname;
        this.order.amount = this.washpack.amount;
        this.order.customerName = this.user.username;
      },
      (error) => {
        console.log(error);

      }
    )

  }

  onSubmit() {
    // console.log(this.order);
    this._order.bookWash(this.order).subscribe(
      (data: any) => {
        console.log(data);
        Swal.fire('Success', `Order Placed!`, 'success');
      },
      (error) => {
        console.log(error);
        // alert("something went wrong")
        this.snack.open("something went wrong!!", "ok", {
          duration: 3000,
          verticalPosition: 'bottom',
          horizontalPosition: 'left'
        })

      }
    )

  }
}

