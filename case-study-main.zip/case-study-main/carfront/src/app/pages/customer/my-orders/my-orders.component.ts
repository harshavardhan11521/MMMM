import { Component, HostListener, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import { OrderService } from 'src/app/services/order.service';
import Swal from 'sweetalert2';


declare var Razorpay: any;



@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent implements OnInit {

  // customer: any = null;

  order = [{
    orderId: '',
    washName: '',
    carModel: '',
    amount: '',
    customerName: '',
    date: '',
    paymentStatus: '',
    emailAddress: ''
  }]

  constructor(private _order: OrderService, private login: LoginService) { }

  ngOnInit(): void {
    this._order.getAllOrdersByCustomerName().subscribe(
      (data: any) => {
        this.order = data;
        console.log(this.order);
      }, (error) => {
        console.log("error");
        Swal.fire('Error!', "Error in loading data!", "error");
      }
    )
  }



  message: any = "Not yet stared";
  paymentId = "";
  error = "";
  title = 'angular-razorpay-intergration';
  options = {
    "key": "rzp_test_EB6MZW7nf4xLXL",
    "amount": "200",
    "name": "Car Wash Express",
    "description": "pay safe with razorpay to car wash express",
    "order_id": "",
    "handler": function (response: any) {
      var event = new CustomEvent("payment.success",
        {
          detail: response,
          bubbles: true,
          cancelable: true
        }
      );
      window.dispatchEvent(event);
    },
    "prefill": {
      "name": "",
      "email": "",
      "contact": ""
    },
    "notes": {
      "address": ""
    },
    "theme": {
      "color": "#3399cc"
    }
  };

  paynow() {
    this.paymentId = '';
    this.error = '';
    this.options.amount = "1235800"
    this.options.prefill.name = "Pradumnya";
    this.options.prefill.email = "";
    this.options.prefill.contact = "";
    var rzp1 = new Razorpay(this.options);
    rzp1.open();
    rzp1.on('payment.failed', function (response: any) {
      //this.message = "Payment Failed";
      // Todo - store this information in the server
      console.log(response.error.code);
      console.log(response.error.description);
      console.log(response.error.source);
      console.log(response.error.step);
      console.log(response.error.reason);
      console.log(response.error.metadata.order_id);
      console.log(response.error.metadata.payment_id);
      //this.error = response.error.reason;
    }
    );
  }
  @HostListener('window:payment.success', ['$event'])
  onPaymentSuccess(event: any): void {
    this.message = "Success Payment";
  }

}
