import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/services/customer.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-load-customers',
  templateUrl: './load-customers.component.html',
  styleUrls: ['./load-customers.component.css']
})
export class LoadCustomersComponent implements OnInit {

  customer = [
    {
      id: '',
      name: '',
      address: '',
      emailAddress: '',
      carModel: ''
    }
  ]

  constructor(private _customer: CustomerService) { }

  ngOnInit(): void {
    this._customer.getAllCustomers().subscribe(
      (data: any) => {
        this.customer = data;
        console.log(this.customer);

      },
      (error) => {
        console.log("error");
        Swal.fire('Error!', "Error in loading data!", "error");

      }
    )
  }

}
