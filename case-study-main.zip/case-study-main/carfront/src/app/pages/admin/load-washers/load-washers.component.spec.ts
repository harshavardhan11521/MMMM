import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadWashersComponent } from './load-washers.component';

describe('LoadWashersComponent', () => {
  let component: LoadWashersComponent;
  let fixture: ComponentFixture<LoadWashersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoadWashersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadWashersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
