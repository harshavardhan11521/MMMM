import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-load-washers',
  templateUrl: './load-washers.component.html',
  styleUrls: ['./load-washers.component.css']
})
export class LoadWashersComponent implements OnInit {

  washer = [
    {
      id: '',
      name: '',
      address: '',
      email: '',
    }
  ]

  constructor(private _washer: AdminService) { }

  ngOnInit(): void {
    this._washer.getAllWashers().subscribe(
      (data: any) => {
        this.washer = data;
        console.log(this.washer);

      },
      (error) => {
        console.log("error");
        Swal.fire('Error!', "Error in loading data!", "error");
      }
    )
  }
}