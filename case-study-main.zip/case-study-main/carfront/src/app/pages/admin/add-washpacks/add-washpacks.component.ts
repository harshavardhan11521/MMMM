import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { WashpackService } from 'src/app/services/washpack.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-washpacks',
  templateUrl: './add-washpacks.component.html',
  styleUrls: ['./add-washpacks.component.css']
})
export class AddWashpacksComponent implements OnInit {

  constructor(private _washpack: WashpackService, private snack: MatSnackBar) { }

  public washpacks = {
    packname: '',
    amount: '',
    description: ''
  }

  ngOnInit(): void {
  }

  formSubmit() {
    console.log(this.washpacks);
    if (this.washpacks.packname == "" || this.washpacks.packname == null) {
      this.snack.open("Packname is required!!", 'ok', {
        duration: 3000,
        verticalPosition: 'bottom',
        horizontalPosition: 'left'
      })
      return;
    }
    this._washpack.addWashpacks(this.washpacks).subscribe(
      (data: any) => {
        console.log(data);
        Swal.fire('Success', `Washpack Added!`, 'success');

      },
      (error) => {
        console.log(error);
        // alert("something went wrong")
        this.snack.open("something went wrong!!", "ok", {
          duration: 3000,
          verticalPosition: 'bottom',
          horizontalPosition: 'left'
        })

      }
    )
  }




}