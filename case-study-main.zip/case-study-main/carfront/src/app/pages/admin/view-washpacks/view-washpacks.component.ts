import { Component, OnInit } from '@angular/core';
import { WashpackService } from 'src/app/services/washpack.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-washpacks',
  templateUrl: './view-washpacks.component.html',
  styleUrls: ['./view-washpacks.component.css']
})
export class ViewWashpacksComponent implements OnInit {

  washpacks = [
    {
      packId: '',
      packname: '',
      amount: '',
      description: ''
    }
  ]

  constructor(private _washpack: WashpackService) { }

  ngOnInit(): void {
    this._washpack.washpacks().subscribe(
      (data: any) => {
        this.washpacks = data;
        console.log(this.washpacks);

      },
      (error) => {
        console.log("error");
        Swal.fire('Error!', "Error in loading data!", "error");

      }
    )
  }

  // delete Washpacks function
  deleteWashpack(packId: any) {

    Swal.fire({
      icon: 'warning',
      title: 'Want to delete?',
      confirmButtonText: 'Delete',
      showCancelButton: true,
    }).then((result) => {

      if (result.isConfirmed) {

        this._washpack.deleteWashpacks(packId).subscribe(
          (data) => {
            this.washpacks = this.washpacks.filter((_washpack) => _washpack.packId != packId);
            Swal.fire("Success", "Washpack Deleted ", 'success');
          }, (error) => {
            console.log(error);

            Swal.fire("Error", "Error in deleting washpack", 'error');

          }

        );
      }

    })
  }

  // update 


}
