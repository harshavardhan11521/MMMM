import { Component, OnInit } from '@angular/core';
import { LeaderboardService } from 'src/app/services/leaderboard.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.component.html',
  styleUrls: ['./leaderboard.component.css']
})
export class LeaderboardComponent implements OnInit {

  leaderboard = [
    {
      rank: '',
      washerName: '',
      waterSavedInliters: ''
    }
  ]

  constructor(private leaderService: LeaderboardService) { }

  ngOnInit(): void {
    this.leaderService.getLeaderboard().subscribe(
      (data: any) => {
        this.leaderboard = data;
        console.log(this.leaderService);

      },
      (error) => {
        console.log("error");
        Swal.fire('Error!', "Error in loading data!", "error");

      }
    )
  }

}
