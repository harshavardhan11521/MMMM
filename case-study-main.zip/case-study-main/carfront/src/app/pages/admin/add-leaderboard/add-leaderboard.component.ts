import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LeaderboardService } from 'src/app/services/leaderboard.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-leaderboard',
  templateUrl: './add-leaderboard.component.html',
  styleUrls: ['./add-leaderboard.component.css']
})
export class AddLeaderboardComponent implements OnInit {

  public leaderboard = {
    rank: '',
    washerName: '',
    waterSavedInliters: ''
  }

  constructor(private leaderService: LeaderboardService, private snack: MatSnackBar) { }

  ngOnInit(): void {
  }
  formSubmit() {
    console.log(this.leaderboard);
    if (this.leaderboard.washerName == "" || this.leaderboard.washerName == null) {
      this.snack.open("washername is required!!", 'ok', {
        duration: 3000,
        verticalPosition: 'bottom',
        horizontalPosition: 'left'
      })
      return;
    }
    this.leaderService.addToLeaderboard(this.leaderboard).subscribe(
      (data: any) => {
        console.log(data);
        Swal.fire('Success', `Washer Added!`, 'success');

      },
      (error) => {
        console.log(error);
        // alert("something went wrong")
        this.snack.open("something went wrong!!", "ok", {
          duration: 3000,
          verticalPosition: 'bottom',
          horizontalPosition: 'left'
        })

      }
    )
  }



}
