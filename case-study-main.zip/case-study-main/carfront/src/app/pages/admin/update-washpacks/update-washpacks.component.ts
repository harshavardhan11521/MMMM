import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { WashpackService } from 'src/app/services/washpack.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-update-washpacks',
  templateUrl: './update-washpacks.component.html',
  styleUrls: ['./update-washpacks.component.css']
})
export class UpdateWashpacksComponent implements OnInit {

  constructor(private _route: ActivatedRoute, private _washpack: WashpackService) { }

  packId = 0;
  washpack: any;

  ngOnInit(): void {

    this.packId = this._route.snapshot.params['packId'];
    // alert(this.packId);
    this._washpack.getWashpack(this.packId).subscribe(
      (data: any) => {
        this.washpack = data;
        console.log(this.washpack);
      },
      (error) => {
        console.log(error);

      }
    )
  }
  // update
  public updateData() {

    this._washpack.updateWashpack(this.washpack, this.packId).subscribe(
      (data: any) => {
        Swal.fire("Updated!!", 'Washpack Updated', 'success');
      }, (error) => {
        Swal.fire("Error", 'Error in updating the washpack', 'error');
        console.log(error);

      }
    )

  }

}
