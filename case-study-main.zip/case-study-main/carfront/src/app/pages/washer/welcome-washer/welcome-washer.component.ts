import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome-washer',
  templateUrl: './welcome-washer.component.html',
  styleUrls: ['./welcome-washer.component.css']
})
export class WelcomeWasherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
