import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-washer-sidebar',
  templateUrl: './washer-sidebar.component.html',
  styleUrls: ['./washer-sidebar.component.css']
})
export class WasherSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
