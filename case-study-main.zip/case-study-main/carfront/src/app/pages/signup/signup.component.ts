import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CustomerService } from 'src/app/services/customer.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private customerService: CustomerService, private snack: MatSnackBar) { }

  public customer = {
    id: '',
    name: '',
    password: '',
    address: '',
    emailAddress: '',
    carModel: '',
    role: ''
  }

  ngOnInit(): void {
  }

  formSubmit() {
    console.log(this.customer);
    if (this.customer.name == "" || this.customer.name == null) {
      // alert("username is required");
      this.snack.open("Customer Name is required!!", 'ok', {
        duration: 3000,
        verticalPosition: 'bottom',
        horizontalPosition: 'left'
      })

      return;
    }

    this.customerService.addCustomer(this.customer).subscribe(
      (data: any) => {
        // success
        console.log(data);
        Swal.fire('Success', `Customer Registered with id ${data.id} </br> Note: Your username is ${data.name}`, 'success');

      },
      (error) => {
        console.log(error);
        // alert("something went wrong")
        this.snack.open("something went wrong!!", "ok", {
          duration: 3000,
          verticalPosition: 'bottom',
          horizontalPosition: 'left'
        })

      }
    )

  }

}
