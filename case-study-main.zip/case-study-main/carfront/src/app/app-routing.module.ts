import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddLeaderboardComponent } from './pages/admin/add-leaderboard/add-leaderboard.component';
import { AddWashpacksComponent } from './pages/admin/add-washpacks/add-washpacks.component';
import { DashboardComponent } from './pages/admin/dashboard/dashboard.component';
import { LeaderboardComponent } from './pages/admin/leaderboard/leaderboard.component';
import { LoadCustomersComponent } from './pages/admin/load-customers/load-customers.component';
import { LoadWashersComponent } from './pages/admin/load-washers/load-washers.component';
import { UpdateWashpacksComponent } from './pages/admin/update-washpacks/update-washpacks.component';
import { ViewWashpacksComponent } from './pages/admin/view-washpacks/view-washpacks.component';
import { WelcomeComponent } from './pages/admin/welcome/welcome.component';
import { CustomerDashboardComponent } from './pages/customer/customer-dashboard/customer-dashboard.component';
import { LoadWashpackComponent } from './pages/customer/load-washpack/load-washpack.component';
import { MyOrdersComponent } from './pages/customer/my-orders/my-orders.component';
import { PlaceOrderComponent } from './pages/customer/place-order/place-order.component';
import { WelcomeCustomerComponent } from './pages/customer/welcome-customer/welcome-customer.component';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { SignupComponent } from './pages/signup/signup.component';
import { WasherDashboardComponent } from './pages/washer/washer-dashboard/washer-dashboard.component';
import { WelcomeWasherComponent } from './pages/washer/welcome-washer/welcome-washer.component';
import { AdminGuard } from './services/admin.guard';
import { CustomerGuard } from './services/customer.guard';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    pathMatch: 'full',
  },
  {
    path: 'signup',
    component: SignupComponent,
    pathMatch: 'full',
  },
  {
    path: 'login',
    component: LoginComponent,
    pathMatch: 'full',
  },
  {
    path: 'admin',
    component: DashboardComponent,
    children: [{
      path: '',
      component: WelcomeComponent,
    },
    {
      path: 'profile',
      component: ProfileComponent,
    },
    {
      path: 'washpack',
      component: ViewWashpacksComponent,
      pathMatch: 'full',
    },
    {
      path: 'add-washpack',
      component: AddWashpacksComponent,
    },
    {
      path: 'welcome',
      component: WelcomeComponent,
    },
    {
      path: 'washpack/:packId',
      component: UpdateWashpacksComponent,
    },
    {
      path: 'leaderboard',
      component: LeaderboardComponent
    },
    {
      path: 'add-leaderboard',
      component: AddLeaderboardComponent
    },
    {
      path: 'all-customers',
      component: LoadCustomersComponent
    },
    {
      path: 'all-washers',
      component: LoadWashersComponent
    }
    ],
    canActivate: [AdminGuard],
  },
  {
    path: 'customer-dashboard',
    component: CustomerDashboardComponent,
    canActivate: [CustomerGuard],
    children: [
      {
        path: 'profile',
        component: ProfileComponent,
      },
      {
        path: 'all-washpacks',
        component: LoadWashpackComponent,
      },
      {
        path: 'welcome-customer',
        component: WelcomeCustomerComponent,
      },
      {
        path: 'my-orders',
        component: MyOrdersComponent,
      },
      {
        path: 'place-order/:packId',
        component: PlaceOrderComponent,
      },
    ]
  },
  {
    path: 'washer-dashboard',
    component: WasherDashboardComponent,
    children: [
      {
        path: 'profile',
        component: ProfileComponent
      },
      {
        path: 'welcome-washer',
        component: WelcomeWasherComponent
      }
    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
