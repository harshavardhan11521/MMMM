import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { SignupComponent } from './pages/signup/signup.component';
import { LoginComponent } from './pages/login/login.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './pages/home/home.component';
import { authInterceptorProviders } from './services/auth.interceptor';
import { DashboardComponent } from './pages/admin/dashboard/dashboard.component';
import { CustomerDashboardComponent } from './pages/customer/customer-dashboard/customer-dashboard.component';
import { WasherDashboardComponent } from './pages/washer/washer-dashboard/washer-dashboard.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { SidebarComponent } from './pages/admin/sidebar/sidebar.component';
import { WelcomeComponent } from './pages/admin/welcome/welcome.component';
import { HeaderComponent } from './pages/admin/header/header.component';
import { ViewWashpacksComponent } from './pages/admin/view-washpacks/view-washpacks.component';
import { AddWashpacksComponent } from './pages/admin/add-washpacks/add-washpacks.component';
import { UpdateWashpacksComponent } from './pages/admin/update-washpacks/update-washpacks.component';
import { CustomerSidebarComponent } from './pages/customer/customer-sidebar/customer-sidebar.component';
import { LoadWashpackComponent } from './pages/customer/load-washpack/load-washpack.component';
import { WelcomeCustomerComponent } from './pages/customer/welcome-customer/welcome-customer.component';
import { WasherSidebarComponent } from './pages/washer/washer-sidebar/washer-sidebar.component';
import { WelcomeWasherComponent } from './pages/washer/welcome-washer/welcome-washer.component';
import { MyOrdersComponent } from './pages/customer/my-orders/my-orders.component';
import { ReactiveFormsModule } from '@angular/forms';
import { LeaderboardComponent } from './pages/admin/leaderboard/leaderboard.component';
import { AddLeaderboardComponent } from './pages/admin/add-leaderboard/add-leaderboard.component';
import { LoadCustomersComponent } from './pages/admin/load-customers/load-customers.component';
import { LoadWashersComponent } from './pages/admin/load-washers/load-washers.component';
import { PlaceOrderComponent } from './pages/customer/place-order/place-order.component';
import { CustomerHeaderComponent } from './pages/customer/customer-header/customer-header.component';
import { WasherHeaderComponent } from './pages/washer/washer-header/washer-header.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    FooterComponent,
    SignupComponent,
    LoginComponent,
    HomeComponent,
    DashboardComponent,
    CustomerDashboardComponent,
    WasherDashboardComponent,
    ProfileComponent,
    SidebarComponent,
    WelcomeComponent,
    HeaderComponent,
    ViewWashpacksComponent,
    AddWashpacksComponent,
    UpdateWashpacksComponent,
    CustomerSidebarComponent,
    LoadWashpackComponent,
    WelcomeCustomerComponent,
    WasherSidebarComponent,
    WelcomeWasherComponent,
    MyOrdersComponent,
    LeaderboardComponent,
    AddLeaderboardComponent,
    LoadCustomersComponent,
    LoadWashersComponent,
    PlaceOrderComponent,
    CustomerHeaderComponent,
    WasherHeaderComponent,
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [authInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
